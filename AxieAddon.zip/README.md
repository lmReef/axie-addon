# Axie-Addon

Addon for Axie Infinity Marketplace.

## Feature list / Behaviors

- Clicking on the extention button while viewing an axie to open a search in a new tab with that axie's class + parts.
- Clicking on the extention button while _not_ on the axie marketplace site (https://marketplace.axieinfinity.com/*) opens the site in a new tab

## Browsers

### Current

- Firefox

### Planned

- Chrome
